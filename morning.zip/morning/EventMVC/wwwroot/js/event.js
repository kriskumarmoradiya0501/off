$(document).ready(function () {

    // Load events

    function loadEvents() {
        $.get('/Event/GetEvents', function (data) {
            $('#eventTable').empty();

            $.each(data, function (i, e) {
                $('#eventTable').append(`
                    <tr>
                        <td>${e.c_eventid}</td>
                        <td>${e.c_eventname}</td>
                        <td>${String(e.c_eventdate).substring(0, 10)}</td>
                        <td>${e.c_eventtime}</td>
                        <td>${e.c_venue}</td>
                        <td>${e.c_totalseats}</td>
                        <td>
                            <button class="btn btn-warning btn-sm editEvent"
                                data-id="${e.c_eventid}">Edit</button>
                            <button class="btn btn-danger btn-sm deleteEvent"
                                data-id="${e.c_eventid}">Delete</button>
                        </td>
                    </tr>
                `);
            });
        }).fail(function () {
            $('#eventMessage').text('Could not load events.');
        });
    }

    loadEvents();

    // Clear form

    function clearForm() {
        $('#eventForm')[0].reset();
        $('#c_eventid').val(0);
    }

    $('#clearForm').click(clearForm);

    // Add or update event

    $('#eventForm').submit(function (e) {
        e.preventDefault();

        let id = Number($('#c_eventid').val());

        let eventData = {
            c_eventid: id,
            c_eventname: $('#c_eventname').val(),
            c_eventdate: $('#c_eventdate').val(),
            c_eventtime: $('#c_eventtime').val(),
            c_venue: $('#c_venue').val(),
            c_totalseats: Number($('#c_totalseats').val())
        };

        let url = id === 0
            ? '/Event/AddEvent'
            : '/Event/UpdateEvent';

        $.ajax({
            url: url,
            type: 'POST',
            contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
            data: eventData,
            success: function (response) {
                $('#eventMessage').text(response.message);
                clearForm();
                loadEvents();
            },
            error: function (xhr) {
                $('#eventMessage').text(
                    xhr.responseText || 'Unable to save event.'
                );
            }
        });
    });

    // Edit event

    $(document).on('click', '.editEvent', function () {
        let id = $(this).data('id');

        $.get('/Event/GetEvent', { id: id }, function (e) {
            $('#c_eventid').val(e.c_eventid);
            $('#c_eventname').val(e.c_eventname);
            $('#c_eventdate').val(
                String(e.c_eventdate).substring(0, 10)
            );
            $('#c_eventtime').val(
                String(e.c_eventtime).substring(0, 5)
            );
            $('#c_venue').val(e.c_venue);
            $('#c_totalseats').val(e.c_totalseats);

            $('#eventMessage').text('Edit the details and click Save Event.');
        });
    });

    // Delete event

    $(document).on('click', '.deleteEvent', function () {
        let id = $(this).data('id');

        if (!confirm('Delete this event?')) return;

        $.post('/Event/DeleteEvent', { id: id }, function (response) {
            $('#eventMessage').text(response.message);
            loadEvents();
        }).fail(function (xhr) {
            $('#eventMessage').text(
                xhr.responseText || 'Unable to delete event.'
            );
        });
    });
});