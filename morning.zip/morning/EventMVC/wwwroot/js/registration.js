$(document).ready(function () {

    // Load events

    function loadEvents() {
        $.get('/Registration/GetEvents', function (data) {
            $('#availableEvents').empty();
            $('#c_eventid').html('<option value="">Select Event</option>');

            $.each(data, function (i, e) {
                $('#availableEvents').append(`
                    <tr>
                        <td>${e.c_eventname}</td>
                        <td>${String(e.c_eventdate).substring(0, 10)}</td>
                        <td>${e.c_eventtime}</td>
                        <td>${e.c_venue}</td>
                        <td>${e.c_totalseats}</td>
                        <td>${e.c_availableseats}</td>
                    </tr>
                `);

                if (e.c_availableseats > 0) {
                    $('#c_eventid').append(`
                        <option value="${e.c_eventid}">
                            ${e.c_eventname}
                        </option>
                    `);
                }
            });
        }).fail(function () {
            $('#registrationMessage').text('Could not load events.');
        });
    }

    // Load my registrations

    function loadMyRegistrations() {
        $.get('/Registration/GetMyRegistrations', function (data) {
            $('#myRegistrations').empty();

            $.each(data, function (i, r) {
                $('#myRegistrations').append(`
                    <tr>
                        <td>${r.c_eventname}</td>
                        <td>${String(r.c_eventdate).substring(0, 10)}</td>
                        <td>${r.c_eventtime}</td>
                        <td>${r.c_venue}</td>
                        <td>${String(r.c_registrationdate).substring(0, 10)}</td>
                        <td>
                            <button class="btn btn-danger btn-sm deleteRegistration"
                                data-id="${r.c_registrationid}">
                                Delete
                            </button>
                        </td>
                    </tr>
                `);
            });
        });
    }

    loadEvents();
    loadMyRegistrations();

    // Add registration

    $('#registrationForm').submit(function (e) {
        e.preventDefault();

        $.ajax({
            url: '/Registration/AddRegistration',
            type: 'POST',
            data: {
                c_eventid: $('#c_eventid').val(),
                c_registrationdate: $('#c_registrationdate').val()
            },
            success: function (response) {
                $('#registrationMessage').text(response.message);

                $('#registrationForm')[0].reset();

                loadEvents();
                loadMyRegistrations();
            },
            error: function (xhr) {
                $('#registrationMessage').text(
                    xhr.responseText || 'Registration failed.'
                );
            }
        });
    });

    // Delete registration

    $(document).on('click', '.deleteRegistration', function () {
        let id = $(this).data('id');

        if (!confirm('Delete this registration?')) return;

        $.post('/Registration/DeleteRegistration', { id: id }, function (response) {
            $('#registrationMessage').text(response.message);

            loadEvents();
            loadMyRegistrations();
        }).fail(function (xhr) {
            $('#registrationMessage').text(
                xhr.responseText || 'Unable to delete registration.'
            );
        });
    });
});