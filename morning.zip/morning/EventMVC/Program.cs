using EventMVC;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddScoped<NpgsqlConnection>(sp =>
{
    var connectionString = sp
        .GetRequiredService<IConfiguration>()
        .GetConnectionString("pgconn");

    return new NpgsqlConnection(connectionString);
});

builder.Services.AddScoped<IUserInterface, UserRepository>();
builder.Services.AddScoped<IEventInterface, EventRepository>();
builder.Services.AddScoped<IRegistrationInterface, RegistrationRepository>();

builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();