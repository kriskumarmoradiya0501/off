﻿namespace EventMVC;

public class UserRegistrationSummary
{
    public string UserName { get; set; } = "";
    public int TotalEventsRegistered { get; set; }
    public DateOnly? LatestRegistrationDate { get; set; }
}
