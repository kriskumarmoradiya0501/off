﻿using System.ComponentModel.DataAnnotations;

namespace EventMVC;

public class t_Event
{
    public int c_eventid { get; set; }

    [Required]
    public string c_eventname { get; set; } = "";

    [Required]
    public DateOnly c_eventdate { get; set; }

    [Required]
    public TimeOnly c_eventtime { get; set; }

    [Required]
    public string c_venue { get; set; } = "";

    [Range(0, int.MaxValue)]
    public int c_totalseats { get; set; }

    public int c_registered { get; set; }

    public int c_availableseats { get; set; }
}