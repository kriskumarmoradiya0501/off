﻿namespace EventMVC;


public class EventSeatReport
{
    public string EventName { get; set; } = "";
    public int TotalSeats { get; set; }
    public int Registered { get; set; }
    public int Remaining { get; set; }
    public decimal Occupancy { get; set; }
}