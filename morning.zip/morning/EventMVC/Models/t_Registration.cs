﻿using System.ComponentModel.DataAnnotations;

namespace EventMVC;

public class t_Registration
{
    public int c_registrationid { get; set; }

    [Required]
    public int c_eventid { get; set; }

    [Required]
    public DateOnly c_registrationdate { get; set; }

    public string c_eventname { get; set; } = "";
    public DateOnly c_eventdate { get; set; }
    public TimeOnly c_eventtime { get; set; }
    public string c_venue { get; set; } = "";
    public int c_totalseats { get; set; }
    public int c_availableseats { get; set; }
}