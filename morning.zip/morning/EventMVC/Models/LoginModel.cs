﻿using System.ComponentModel.DataAnnotations;

namespace EventMVC;

public class LoginModel
{
    [Required]
    [EmailAddress]
    public string c_email { get; set; } = "";

    [Required]
    public string c_password { get; set; } = "";
}
