﻿namespace EventMVC;

public class t_User
{
    public int c_userid { get; set; }
    public string c_name { get; set; } = "";
    public string c_email { get; set; } = "";
    public string c_password { get; set; } = "";
    public string c_mobile { get; set; } = "";
    public string c_gender { get; set; } = "";
    public string c_role { get; set; } = "";
}
