﻿namespace EventMVC;

public interface IUserInterface
{
    Task<t_User?> Login(string email, string password);
}
