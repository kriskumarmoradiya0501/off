﻿namespace EventMVC;

public interface IRegistrationInterface
{
    Task<List<t_Registration>> GetMyRegistrations(int userId);
    Task<int> Add(t_Registration item, int userId);
    Task<int> Delete(int id, int userId);
}
