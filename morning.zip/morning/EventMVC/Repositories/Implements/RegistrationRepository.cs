﻿
using Npgsql;

namespace EventMVC;

public class RegistrationRepository : IRegistrationInterface
{
    private readonly NpgsqlConnection _connection;

    public RegistrationRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    // My registrations

    public async Task<List<t_Registration>> GetMyRegistrations(int userId)
    {
        List<t_Registration> registrations = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT r.c_registrationid,
                       r.c_eventid,
                       r.c_registrationdate,
                       e.c_eventname,
                       e.c_eventdate,
                       e.c_eventtime,
                       e.c_venue,
                       e.c_totalseats,
                       e.c_totalseats -
                       (
                           SELECT COUNT(*)::INT
                           FROM t_registration x
                           WHERE x.c_eventid = e.c_eventid
                       ) AS available
                FROM t_registration r
                INNER JOIN t_event e
                    ON r.c_eventid = e.c_eventid
                WHERE r.c_userid = @userId
                ORDER BY r.c_registrationdate DESC;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@userId", userId);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                registrations.Add(new t_Registration
                {
                    c_registrationid =
                        Convert.ToInt32(reader["c_registrationid"]),
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_registrationdate =
                        (DateOnly)reader["c_registrationdate"],
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = (DateOnly)reader["c_eventdate"],
                    c_eventtime = (TimeOnly)reader["c_eventtime"],
                    c_venue = reader["c_venue"].ToString()!,
                    c_totalseats = Convert.ToInt32(reader["c_totalseats"]),
                    c_availableseats = Convert.ToInt32(reader["available"])
                });
            }

            return registrations;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Add registration

    public async Task<int> Add(t_Registration item, int userId)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                INSERT INTO t_registration
                    (c_userid, c_eventid, c_registrationdate)
                SELECT @userId, e.c_eventid, @registrationDate
                FROM t_event e
                WHERE e.c_eventid = @eventId
                  AND e.c_totalseats > (
                      SELECT COUNT(*)::INT
                      FROM t_registration r
                      WHERE r.c_eventid = e.c_eventid
                  )
                ON CONFLICT (c_userid, c_eventid) DO NOTHING;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@userId", userId);
            command.Parameters.AddWithValue("@eventId", item.c_eventid);
            command.Parameters.AddWithValue(
                "@registrationDate", item.c_registrationdate);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Delete own registration

    public async Task<int> Delete(int id, int userId)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                DELETE FROM t_registration
                WHERE c_registrationid = @id
                  AND c_userid = @userId;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@userId", userId);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}