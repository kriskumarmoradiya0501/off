﻿
using Npgsql;

namespace EventMVC;

public class EventRepository : IEventInterface
{
    private readonly NpgsqlConnection _connection;

    public EventRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    // Event table

    public async Task<List<t_Event>> GetAll()
    {
        List<t_Event> events = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.*,
                       COUNT(r.c_registrationid)::INT AS registered
                FROM t_event e
                LEFT JOIN t_registration r
                    ON e.c_eventid = r.c_eventid
                GROUP BY e.c_eventid
                ORDER BY e.c_eventid;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                int total = Convert.ToInt32(reader["c_totalseats"]);
                int registered = Convert.ToInt32(reader["registered"]);

                events.Add(new t_Event
                {
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = (DateOnly)reader["c_eventdate"],
                    c_eventtime = (TimeOnly)reader["c_eventtime"],
                    c_venue = reader["c_venue"].ToString()!,
                    c_totalseats = total,
                    c_registered = registered,
                    c_availableseats = total - registered
                });
            }

            return events;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<t_Event?> GetById(int id)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT *
                FROM t_event
                WHERE c_eventid = @id;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new t_Event
                {
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = (DateOnly)reader["c_eventdate"],
                    c_eventtime = (TimeOnly)reader["c_eventtime"],
                    c_venue = reader["c_venue"].ToString()!,
                    c_totalseats = Convert.ToInt32(reader["c_totalseats"])
                };
            }

            return null;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Add event

    public async Task<int> Add(t_Event item)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                INSERT INTO t_event
                (c_eventname, c_eventdate, c_eventtime,
                 c_venue, c_totalseats)
                VALUES
                (@name, @date, @time, @venue, @seats);
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@name", item.c_eventname);
            command.Parameters.AddWithValue("@date", item.c_eventdate);
            command.Parameters.AddWithValue("@time", item.c_eventtime);
            command.Parameters.AddWithValue("@venue", item.c_venue);
            command.Parameters.AddWithValue("@seats", item.c_totalseats);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Update event

    public async Task<int> Update(t_Event item)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                UPDATE t_event
                SET c_eventname = @name,
                    c_eventdate = @date,
                    c_eventtime = @time,
                    c_venue = @venue,
                    c_totalseats = @seats
                WHERE c_eventid = @id
                AND @seats >= (
                    SELECT COUNT(*)
                    FROM t_registration
                    WHERE c_eventid = @id
                );
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", item.c_eventid);
            command.Parameters.AddWithValue("@name", item.c_eventname);
            command.Parameters.AddWithValue("@date", item.c_eventdate);
            command.Parameters.AddWithValue("@time", item.c_eventtime);
            command.Parameters.AddWithValue("@venue", item.c_venue);
            command.Parameters.AddWithValue("@seats", item.c_totalseats);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Delete event

    public async Task<int> Delete(int id)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                DELETE FROM t_event
                WHERE c_eventid = @id;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Event seat availability report

    public async Task<List<EventSeatReport>> GetSeatReport()
    {
        List<EventSeatReport> reports = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.c_eventname,
                       e.c_totalseats,
                       COUNT(r.c_registrationid)::INT AS registered,
                       e.c_totalseats - COUNT(r.c_registrationid)::INT AS remaining,
                       COALESCE(
                           ROUND(
                               COUNT(r.c_registrationid)::NUMERIC
                               * 100 / NULLIF(e.c_totalseats, 0), 2
                           ), 0
                       ) AS occupancy
                FROM t_event e
                LEFT JOIN t_registration r
                    ON e.c_eventid = r.c_eventid
                GROUP BY e.c_eventid
                ORDER BY e.c_eventid;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                reports.Add(new EventSeatReport
                {
                    EventName = reader["c_eventname"].ToString()!,
                    TotalSeats = Convert.ToInt32(reader["c_totalseats"]),
                    Registered = Convert.ToInt32(reader["registered"]),
                    Remaining = Convert.ToInt32(reader["remaining"]),
                    Occupancy = Convert.ToDecimal(reader["occupancy"])
                });
            }

            return reports;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // User registration summary

    public async Task<List<UserRegistrationSummary>> GetUserSummary()
    {
        List<UserRegistrationSummary> reports = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT u.c_name,
                       COUNT(r.c_registrationid)::INT AS total,
                       MAX(r.c_registrationdate) AS latest
                FROM t_user u
                INNER JOIN t_registration r
                    ON u.c_userid = r.c_userid
                WHERE u.c_role = 'User'
                GROUP BY u.c_userid
                ORDER BY u.c_name;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                reports.Add(new UserRegistrationSummary
                {
                    UserName = reader["c_name"].ToString()!,
                    TotalEventsRegistered =
                        Convert.ToInt32(reader["total"]),
                    LatestRegistrationDate =
                        reader["latest"] == DBNull.Value
                            ? null
                            : DateOnly.FromDateTime(
                                Convert.ToDateTime(reader["latest"]))
                });
            }

            return reports;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}