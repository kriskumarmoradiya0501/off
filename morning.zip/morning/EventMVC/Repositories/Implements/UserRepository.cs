﻿
using Npgsql;

namespace EventMVC;

public class UserRepository : IUserInterface
{
    private readonly NpgsqlConnection _connection;

    public UserRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<t_User?> Login(string email, string password)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT *
                FROM t_user
                WHERE LOWER(c_email) = LOWER(@email)
                AND c_password = @password;
            ";

            using NpgsqlCommand command =
                new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);

            using NpgsqlDataReader reader =
                await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new t_User
                {
                    c_userid = Convert.ToInt32(reader["c_userid"]),
                    c_name = reader["c_name"].ToString()!,
                    c_email = reader["c_email"].ToString()!,
                    c_password = reader["c_password"].ToString()!,
                    c_mobile = reader["c_mobile"] == DBNull.Value
                        ? "" : reader["c_mobile"].ToString()!,
                    c_gender = reader["c_gender"] == DBNull.Value
                        ? "" : reader["c_gender"].ToString()!,
                    c_role = reader["c_role"].ToString()!
                };
            }

            return null;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}