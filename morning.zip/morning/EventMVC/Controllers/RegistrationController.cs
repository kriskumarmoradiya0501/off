﻿
using Microsoft.AspNetCore.Mvc;

namespace EventMVC;

public class RegistrationController : Controller
{
    private readonly IRegistrationInterface _registrationRepository;
    private readonly IEventInterface _eventRepository;

    public RegistrationController(
        IRegistrationInterface registrationRepository,
        IEventInterface eventRepository)
    {
        _registrationRepository = registrationRepository;
        _eventRepository = eventRepository;
    }

    private bool IsUser()
    {
        return HttpContext.Session.GetString("UserRole") == "User";
    }

    // Registration page

    public IActionResult Index()
    {
        if (!IsUser())
            return RedirectToAction("Login", "Account");

        return View();
    }

    // Get available events

    [HttpGet]
    public async Task<IActionResult> GetEvents()
    {
        if (!IsUser())
            return Unauthorized();

        var events = await _eventRepository.GetAll();

        return Json(events.Select(e => new
        {
            e.c_eventid,
            e.c_eventname,
            e.c_eventdate,
            e.c_eventtime,
            e.c_venue,
            e.c_totalseats,
            e.c_availableseats
        }));
    }

    // My registrations

    [HttpGet]
    public async Task<IActionResult> GetMyRegistrations()
    {
        if (!IsUser())
            return Unauthorized();

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        return Json(
            await _registrationRepository.GetMyRegistrations(userId));
    }

    // Add registration

    [HttpPost]
    public async Task<IActionResult> AddRegistration(t_Registration item)
    {
        if (!IsUser())
            return Unauthorized();

        if (!ModelState.IsValid ||
            item.c_eventid <= 0 ||
            item.c_registrationdate == default)
        {
            return BadRequest("Select an event and registration date.");
        }

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        int result = await _registrationRepository.Add(item, userId);

        if (result == 0)
            return BadRequest(
                "Registration failed. The event may be full or already registered.");

        return Json(new
        {
            success = true,
            message = "Event registered successfully."
        });
    }

    // Delete registration

    [HttpPost]
    public async Task<IActionResult> DeleteRegistration(int id)
    {
        if (!IsUser())
            return Unauthorized();

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        int result = await _registrationRepository.Delete(id, userId);

        if (result == 0)
            return NotFound("Registration not found.");

        return Json(new
        {
            success = true,
            message = "Registration deleted."
        });
    }
}