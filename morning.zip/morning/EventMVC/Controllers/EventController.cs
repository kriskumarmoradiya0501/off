﻿using Microsoft.AspNetCore.Mvc;

namespace EventMVC;

public class EventController : Controller
{
    private readonly IEventInterface _eventRepository;

    public EventController(IEventInterface eventRepository)
    {
        _eventRepository = eventRepository;
    }

    private bool IsAdmin()
    {
        return HttpContext.Session.GetString("UserRole") == "Admin";
    }

    // Event page

    public IActionResult Index()
    {
        if (!IsAdmin())
            return RedirectToAction("Login", "Account");

        return View();
    }

    // Get events

    [HttpGet]
    public async Task<IActionResult> GetEvents()
    {
        if (!IsAdmin())
            return Unauthorized();

        return Json(await _eventRepository.GetAll());
    }

    // Add event

    [HttpPost]
    public async Task<IActionResult> AddEvent(t_Event item)
    {
        if (!IsAdmin())
            return Unauthorized();

        if (!ModelState.IsValid || item.c_totalseats < 0)
            return BadRequest("Enter valid event details.");

        int result = await _eventRepository.Add(item);

        return result > 0
            ? Json(new { success = true, message = "Event added." })
            : BadRequest("Event was not added.");
    }

    // Get event by id

    [HttpGet]
    public async Task<IActionResult> GetEvent(int id)
    {
        if (!IsAdmin())
            return Unauthorized();

        var item = await _eventRepository.GetById(id);

        return item == null ? NotFound() : Json(item);
    }

    // Update event

    [HttpPost]
    public async Task<IActionResult> UpdateEvent(t_Event item)
    {
        if (!IsAdmin())
            return Unauthorized();

        if (!ModelState.IsValid || item.c_totalseats < 0)
            return BadRequest("Enter valid event details.");

        int result = await _eventRepository.Update(item);

        if (result == 0)
            return BadRequest(
                "Event was not updated. Check its ID and registered seat count.");

        return Json(new { success = true, message = "Event updated." });
    }

    // Delete event

    [HttpPost]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        if (!IsAdmin())
            return Unauthorized();

        int result = await _eventRepository.Delete(id);

        if (result == 0)
            return BadRequest(
                "Event was not deleted. It may have registrations.");

        return Json(new { success = true, message = "Event deleted." });
    }

    // Seat report

    [HttpGet]
    public async Task<IActionResult> GetSeatReport()
    {
        if (!IsAdmin())
            return Unauthorized();

        return Json(await _eventRepository.GetSeatReport());
    }

    // Registration summary

    [HttpGet]
    public async Task<IActionResult> GetUserSummary()
    {
        if (!IsAdmin())
            return Unauthorized();

        return Json(await _eventRepository.GetUserSummary());
    }
}