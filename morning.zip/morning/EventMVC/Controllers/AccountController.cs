﻿using EventMVC;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC;
public class AccountController : Controller
{
    private readonly IUserInterface _userRepository;

    public AccountController(IUserInterface userRepository)
    {
        _userRepository = userRepository;
    }

    // Login

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

[HttpPost]
public async Task<IActionResult> Login(LoginModel model)
{
    if (!ModelState.IsValid)
    {
        return View(model);
    }

    var user = await _userRepository.Login(
        model.c_email,
        model.c_password
    );

    if (user == null)
    {
        ModelState.AddModelError("", "Invalid email or password.");
        return View(model);
    }

    // Store session
    HttpContext.Session.SetInt32("UserId", user.c_userid);
    HttpContext.Session.SetString("UserName", user.c_name);
    HttpContext.Session.SetString("UserEmail", user.c_email);
    HttpContext.Session.SetString("UserRole", user.c_role ?? "User");

    // Redirect according to role
    if (user.c_role == "Admin")
    {
        return RedirectToAction("AdminDashboard", "Home");
    }
    else
    {
        return RedirectToAction("UserDashboard", "Home");
    }
}    // Logout

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}