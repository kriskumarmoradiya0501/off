using Microsoft.AspNetCore.Mvc;

namespace EventMVC;

public class HomeController : Controller
{
    // Admin dashboard

    public IActionResult AdminDashboard()
    {
        if (HttpContext.Session.GetString("UserRole") != "Admin")
            return RedirectToAction("Login", "Account");

        return View();
    }

    // User dashboard

    public IActionResult UserDashboard()
    {
        if (HttpContext.Session.GetString("UserRole") != "User")
            return RedirectToAction("Login", "Account");

        return View();
    }
}