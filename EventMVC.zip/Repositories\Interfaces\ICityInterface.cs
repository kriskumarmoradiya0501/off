﻿using EventMVC.Models;

namespace EventMVC.Repositories.Interfaces;

public interface ICityInterface
{
    Task<List<t_City>> GetAllCities();
}