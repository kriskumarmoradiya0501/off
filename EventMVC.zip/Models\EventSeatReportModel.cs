﻿namespace EventMVC.Models;

public class EventSeatReportModel
{
    public string EventName { get; set; } = "";

    public int TotalSeats { get; set; }

    public int RegisteredSeats { get; set; }

    public int RemainingSeats { get; set; }

    public string OccupancyPercentage { get; set; } = "0%";
}