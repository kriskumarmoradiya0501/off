﻿using EventMVC.Models;

namespace EventMVC.Repositories.Interfaces;

public interface IReportInterface
{
    Task<List<EventSeatReportModel>> GetSeatAvailabilityReport();
    Task<List<UserSummaryReportModel>> GetUserRegistrationSummary();
    Task<List<EventAvailabilityStatusModel>> GetLowAvailabilityReport();
}