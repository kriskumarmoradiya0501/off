﻿namespace EventMVC.Models;

public class UserSummaryReportModel
{
    public string UserName { get; set; } = "";

    public int TotalEventsRegistered { get; set; }

    public string LatestRegistration { get; set; } = "-";
}