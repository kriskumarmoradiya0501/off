﻿using EventMVC.Models;

namespace EventMVC.Repositories.Interfaces;

public interface IUserInterface
{
    Task<t_User?> Login(string email, string password);
    Task<bool> EmailExists(string email);
    Task<int> RegisterUser(t_User user);
    Task<t_User?> GetById(int id);
}