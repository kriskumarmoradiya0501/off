﻿using EventMVC.Models;

namespace EventMVC.Repositories.Interfaces;

public interface IEventInterface
{
    Task<List<t_Event>> GetAll();
    Task<t_Event?> GetById(int id);
    Task<int> Add(t_Event item);
    Task<int> Update(t_Event item);
    Task<int> Delete(int id);
}