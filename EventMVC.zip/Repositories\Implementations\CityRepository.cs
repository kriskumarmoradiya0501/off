﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Npgsql;

namespace EventMVC.Repositories.Implementations;

public class CityRepository : ICityInterface
{
    private readonly NpgsqlConnection _connection;

    public CityRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<List<t_City>> GetAllCities()
    {
        List<t_City> cities = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT c_cityid, c_cityname
                FROM t_city
                ORDER BY c_cityname ASC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                cities.Add(new t_City
                {
                    c_cityid = Convert.ToInt32(reader["c_cityid"]),
                    c_cityname = reader["c_cityname"].ToString()!
                });
            }

            return cities;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}