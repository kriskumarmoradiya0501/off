﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Npgsql;

namespace EventMVC.Repositories.Implementations;

public class EventRepository : IEventInterface
{
    private readonly NpgsqlConnection _connection;

    public EventRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<List<t_Event>> GetAll()
    {
        List<t_Event> events = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.c_eventid, e.c_cityid, c.c_cityname, e.c_eventname,
                       e.c_eventdate, e.c_eventtime, e.c_venue, e.c_eventimage,
                       e.c_eventtype, e.c_foodpreference, e.c_totalseats,
                       e.c_totalseats - COALESCE(
                           (SELECT COUNT(*)::INT FROM t_registration r WHERE r.c_eventid = e.c_eventid), 0
                       ) AS available
                FROM t_event e
                LEFT JOIN t_city c ON e.c_cityid = c.c_cityid
                ORDER BY e.c_eventdate ASC, e.c_eventtime ASC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                events.Add(new t_Event
                {
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_cityid = Convert.ToInt32(reader["c_cityid"]),
                    c_cityname = reader["c_cityname"] == DBNull.Value ? "" : reader["c_cityname"].ToString()!,
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = DateOnly.FromDateTime(Convert.ToDateTime(reader["c_eventdate"])),
                    c_eventtime = TimeOnly.FromTimeSpan((TimeSpan)reader["c_eventtime"]),
                    c_venue = reader["c_venue"].ToString()!,
                    c_eventimage = reader["c_eventimage"] == DBNull.Value ? "" : reader["c_eventimage"].ToString(),
                    c_eventtype = reader["c_eventtype"].ToString()!,
                    c_foodpreference = reader["c_foodpreference"].ToString()!,
                    c_totalseats = Convert.ToInt32(reader["c_totalseats"]),
                    c_availableseats = Convert.ToInt32(reader["available"])
                });
            }

            return events;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<t_Event?> GetById(int id)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.c_eventid, e.c_cityid, c.c_cityname, e.c_eventname,
                       e.c_eventdate, e.c_eventtime, e.c_venue, e.c_eventimage,
                       e.c_eventtype, e.c_foodpreference, e.c_totalseats,
                       e.c_totalseats - COALESCE(
                           (SELECT COUNT(*)::INT FROM t_registration r WHERE r.c_eventid = e.c_eventid), 0
                       ) AS available
                FROM t_event e
                LEFT JOIN t_city c ON e.c_cityid = c.c_cityid
                WHERE e.c_eventid = @id;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new t_Event
                {
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_cityid = Convert.ToInt32(reader["c_cityid"]),
                    c_cityname = reader["c_cityname"] == DBNull.Value ? "" : reader["c_cityname"].ToString()!,
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = DateOnly.FromDateTime(Convert.ToDateTime(reader["c_eventdate"])),
                    c_eventtime = TimeOnly.FromTimeSpan((TimeSpan)reader["c_eventtime"]),
                    c_venue = reader["c_venue"].ToString()!,
                    c_eventimage = reader["c_eventimage"] == DBNull.Value ? "" : reader["c_eventimage"].ToString(),
                    c_eventtype = reader["c_eventtype"].ToString()!,
                    c_foodpreference = reader["c_foodpreference"].ToString()!,
                    c_totalseats = Convert.ToInt32(reader["c_totalseats"]),
                    c_availableseats = Convert.ToInt32(reader["available"])
                };
            }

            return null;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Add(t_Event item)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                INSERT INTO t_event (
                    c_cityid, c_eventname, c_eventdate, c_eventtime,
                    c_venue, c_eventimage, c_eventtype, c_foodpreference, c_totalseats
                ) VALUES (
                    @cityid, @name, @date, @time,
                    @venue, @img, @type, @food, @seats
                );
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@cityid", item.c_cityid);
            command.Parameters.AddWithValue("@name", item.c_eventname);
            command.Parameters.AddWithValue("@date", item.c_eventdate);
            command.Parameters.AddWithValue("@time", item.c_eventtime.ToTimeSpan());
            command.Parameters.AddWithValue("@venue", item.c_venue);
            command.Parameters.AddWithValue("@img", (object?)item.c_eventimage ?? DBNull.Value);
            command.Parameters.AddWithValue("@type", item.c_eventtype ?? "Solo");
            command.Parameters.AddWithValue("@food", item.c_foodpreference ?? "Veg");
            command.Parameters.AddWithValue("@seats", item.c_totalseats);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Update(t_Event item)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                UPDATE t_event
                SET c_cityid = @cityid,
                    c_eventname = @name,
                    c_eventdate = @date,
                    c_eventtime = @time,
                    c_venue = @venue,
                    c_eventimage = COALESCE(@img, c_eventimage),
                    c_eventtype = @type,
                    c_foodpreference = @food,
                    c_totalseats = @seats
                WHERE c_eventid = @id
                  AND @seats >= (SELECT COUNT(*)::INT FROM t_registration WHERE c_eventid = @id);
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", item.c_eventid);
            command.Parameters.AddWithValue("@cityid", item.c_cityid);
            command.Parameters.AddWithValue("@name", item.c_eventname);
            command.Parameters.AddWithValue("@date", item.c_eventdate);
            command.Parameters.AddWithValue("@time", item.c_eventtime.ToTimeSpan());
            command.Parameters.AddWithValue("@venue", item.c_venue);
            command.Parameters.AddWithValue("@img", (object?)item.c_eventimage ?? DBNull.Value);
            command.Parameters.AddWithValue("@type", item.c_eventtype ?? "Solo");
            command.Parameters.AddWithValue("@food", item.c_foodpreference ?? "Veg");
            command.Parameters.AddWithValue("@seats", item.c_totalseats);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Delete(int id)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                DELETE FROM t_event
                WHERE c_eventid = @id
                  AND NOT EXISTS (SELECT 1 FROM t_registration WHERE c_eventid = @id);
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}