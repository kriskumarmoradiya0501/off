﻿using EventMVC.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class CityController : Controller
{
    private readonly ICityInterface _cityRepository;

    public CityController(ICityInterface cityRepository)
    {
        _cityRepository = cityRepository;
    }

    [HttpGet]
    public async Task<IActionResult> GetCities()
    {
        var cities = await _cityRepository.GetAllCities();
        return Json(cities);
    }
}