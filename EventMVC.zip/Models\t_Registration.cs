﻿namespace EventMVC.Models;

public class t_Registration
{
    public int c_registrationid { get; set; }

    public int c_userid { get; set; }

    public int c_eventid { get; set; }

    public DateOnly c_registrationdate { get; set; }

    public string c_eventname { get; set; } = "";

    public string c_cityname { get; set; } = "";

    public DateOnly c_eventdate { get; set; }

    public TimeOnly c_eventtime { get; set; }

    public string c_venue { get; set; } = "";

    public string? c_eventimage { get; set; }

    public string c_eventtype { get; set; } = "";

    public string c_foodpreference { get; set; } = "";

    public int c_totalseats { get; set; }

    public int c_availableseats { get; set; }
}