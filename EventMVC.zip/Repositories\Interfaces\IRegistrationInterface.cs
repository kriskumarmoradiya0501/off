﻿using EventMVC.Models;

namespace EventMVC.Repositories.Interfaces;

public interface IRegistrationInterface
{
    Task<List<t_Registration>> GetMyRegistrations(int userId);
    Task<int> Register(int userId, int eventId, DateOnly registrationDate);
    Task<int> Cancel(int registrationId, int userId);
    Task<bool> IsAlreadyRegistered(int userId, int eventId);
}