﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class AccountController : Controller
{
    private readonly IUserInterface _userRepository;
    private readonly IWebHostEnvironment _environment;

    public AccountController(IUserInterface userRepository, IWebHostEnvironment environment)
    {
        _userRepository = userRepository;
        _environment = environment;
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Login([FromForm] LoginModel model)
    {
        if (!ModelState.IsValid)
        {
            return Json(new { success = false, message = "Please enter both email and password." });
        }

        var user = await _userRepository.Login(model.c_email, model.c_password);

        if (user == null)
        {
            return Json(new { success = false, message = "Invalid email or password." });
        }

        HttpContext.Session.SetInt32("UserId", user.c_userid);
        HttpContext.Session.SetString("UserName", user.c_name);
        HttpContext.Session.SetString("UserEmail", user.c_email);
        HttpContext.Session.SetString("UserRole", user.c_role);

        string redirectUrl = user.c_role == "Admin"
            ? Url.Action("Index", "Event")!
            : Url.Action("Index", "Registration")!;

        return Json(new { success = true, redirectUrl });
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register([FromForm] t_User model)
    {
        if (await _userRepository.EmailExists(model.c_email))
        {
            return Json(new { success = false, message = "Email already registered. Try another." });
        }

        if (model.ProfileImageFile != null && model.ProfileImageFile.Length > 0)
        {
            string folder = Path.Combine(_environment.WebRootPath, "uploads");

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string uniqueName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(model.ProfileImageFile.FileName);
            string filePath = Path.Combine(folder, uniqueName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await model.ProfileImageFile.CopyToAsync(stream);
            }

            model.c_profileimage = "/uploads/" + uniqueName;
        }

        int result = await _userRepository.RegisterUser(model);

        if (result > 0)
        {
            return Json(new { success = true, message = "Registration successful! Redirecting to login..." });
        }

        return Json(new { success = false, message = "Registration failed." });
    }

    [HttpGet]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}