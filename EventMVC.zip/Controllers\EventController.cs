﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class EventController : Controller
{
    private readonly IEventInterface _eventRepository;
    private readonly IWebHostEnvironment _environment;

    public EventController(IEventInterface eventRepository, IWebHostEnvironment environment)
    {
        _eventRepository = eventRepository;
        _environment = environment;
    }

    private bool IsAdmin()
    {
        return HttpContext.Session.GetString("UserRole") == "Admin";
    }

    [HttpGet]
    public IActionResult Index()
    {
        if (!IsAdmin())
        {
            return RedirectToAction("Login", "Account");
        }

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> Read()
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        var events = await _eventRepository.GetAll();

        return Json(events);
    }

    [HttpPost]
    public async Task<IActionResult> Create(t_Event model)
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        if (!ModelState.IsValid || model.c_totalseats < 0)
        {
            return BadRequest(new { success = false, message = "Enter valid event details." });
        }

        int result = await _eventRepository.Add(model);

        if (result > 0)
        {
            return Json(new { success = true, message = "Event added successfully." });
        }

        return BadRequest(new { success = false, message = "Failed to add event." });
    }

    [HttpPost]
    public async Task<IActionResult> Update(t_Event model)
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        if (!ModelState.IsValid || model.c_totalseats < 0)
        {
            return BadRequest(new { success = false, message = "Enter valid event details." });
        }

        int result = await _eventRepository.Update(model);

        if (result > 0)
        {
            return Json(new { success = true, message = "Event updated successfully." });
        }

        return BadRequest(new { success = false, message = "Cannot reduce seats below registered count." });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int c_eventid)
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        int result = await _eventRepository.Delete(c_eventid);

        if (result > 0)
        {
            return Json(new { success = true, message = "Event deleted successfully." });
        }

        return BadRequest(new { success = false, message = "Cannot delete event with existing registrations." });
    }

    [HttpPost]
    public async Task<IActionResult> UploadEventImage(IFormFile files)
    {
        if (files != null && files.Length > 0)
        {
            string folder = Path.Combine(_environment.WebRootPath, "uploads");

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            string uniqueName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(files.FileName);
            string filePath = Path.Combine(folder, uniqueName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await files.CopyToAsync(stream);
            }

            return Json(new { filePath = "/uploads/" + uniqueName });
        }

        return BadRequest();
    }
}