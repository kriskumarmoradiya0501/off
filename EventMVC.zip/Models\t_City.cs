﻿namespace EventMVC.Models;

public class t_City
{
    public int c_cityid { get; set; }

    public string c_cityname { get; set; } = "";
}