﻿using EventMVC.Repositories.Implementations;
using EventMVC.Repositories.Interfaces;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);

// Controllers and JSON
builder.Services.AddControllersWithViews()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null;
    });

// Npgsql connection registration
builder.Services.AddScoped<NpgsqlConnection>(serviceProvider =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();

    var connectionString = configuration.GetConnectionString("pgconn");

    return new NpgsqlConnection(connectionString);
});

// Repositories
builder.Services.AddScoped<ICityInterface, CityRepository>();
builder.Services.AddScoped<IUserInterface, UserRepository>();
builder.Services.AddScoped<IEventInterface, EventRepository>();
builder.Services.AddScoped<IRegistrationInterface, RegistrationRepository>();
builder.Services.AddScoped<IReportInterface, ReportRepository>();

// Session configuration with 20 minutes inactivity timeout
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

// Default route directly to Login
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();