﻿-- 1. CITY TABLE
CREATE TABLE IF NOT EXISTS t_city (
    c_cityid SERIAL PRIMARY KEY,
    c_cityname VARCHAR(100) NOT NULL
);

INSERT INTO t_city (c_cityid, c_cityname) VALUES
    (1, 'Ahmedabad'),
    (2, 'Mumbai'),
    (3, 'Delhi'),
    (4, 'Bangalore'),
    (5, 'Pune')
ON CONFLICT (c_cityid) DO NOTHING;

-- 2. USER TABLE
CREATE TABLE IF NOT EXISTS t_user (
    c_userid SERIAL PRIMARY KEY,
    c_name VARCHAR(100) NOT NULL,
    c_email VARCHAR(150) UNIQUE NOT NULL,
    c_password VARCHAR(255) NOT NULL,
    c_mobile VARCHAR(15) NOT NULL,
    c_gender VARCHAR(20) NOT NULL,
    c_hobbies VARCHAR(200),
    c_cityid INT REFERENCES t_city(c_cityid),
    c_profileimage VARCHAR(255),
    c_role VARCHAR(50) NOT NULL DEFAULT 'User'
);

INSERT INTO t_user (
    c_userid, c_name, c_email, c_password,
    c_mobile, c_gender, c_cityid, c_role
) VALUES
    (101, 'Admin User', 'admin@event.com', 'Admin@123', '9876543210', 'Male', 1, 'Admin'),
    (102, 'Rahul Patel', 'rahul@gmail.com', 'Rahul@123', '9876543211', 'Male', 1, 'User'),
    (103, 'Priya Shah', 'priya@gmail.com', 'Priya@123', '9876543212', 'Female', 2, 'User'),
    (104, 'Amit Mehta', 'amit@gmail.com', 'Amit@123', '9876543213', 'Male', 3, 'User'),
    (105, 'Neha Patel', 'neha@gmail.com', 'Neha@123', '9876543214', 'Female', 4, 'User')
ON CONFLICT (c_userid) DO NOTHING;

SELECT setval(
    't_user_c_userid_seq',
    GREATEST((SELECT MAX(c_userid) FROM t_user), 1),
    (SELECT MAX(c_userid) IS NOT NULL FROM t_user)
);

-- 3. EVENT TABLE
CREATE TABLE IF NOT EXISTS t_event (
    c_eventid SERIAL PRIMARY KEY,
    c_cityid INT REFERENCES t_city(c_cityid),
    c_eventname VARCHAR(150) NOT NULL,
    c_eventdate DATE NOT NULL,
    c_eventtime TIME NOT NULL,
    c_venue VARCHAR(200) NOT NULL,
    c_eventimage VARCHAR(255),
    c_eventtype VARCHAR(50) DEFAULT 'Solo',
    c_foodpreference VARCHAR(100) DEFAULT 'Veg',
    c_totalseats INT NOT NULL CHECK (c_totalseats >= 0)
);

INSERT INTO t_event (
    c_eventid, c_cityid, c_eventname, c_eventdate,
    c_eventtime, c_venue, c_eventtype,
    c_foodpreference, c_totalseats
) VALUES
    (201, 1, 'Tech Conference', '2026-10-20', '10:00:00', 'Grand Hall', 'Group', 'Veg, Non-Veg', 100),
    (202, 2, 'AI Workshop', '2026-10-25', '14:00:00', 'Innovation Hub', 'Solo', 'Veg', 50),
    (203, 3, 'Music Concert', '2026-11-05', '19:00:00', 'Open Arena', 'Group', 'Non-Veg', 500),
    (204, 4, '.NET Developer Meet', '2026-11-10', '11:00:00', 'Tech Center', 'Solo', 'Veg, Non-Veg', 75),
    (205, 5, 'Database Workshop', '2026-11-15', '10:00:00', 'Training Hall', 'Solo', 'Veg', 40)
ON CONFLICT (c_eventid) DO NOTHING;

SELECT setval(
    't_event_c_eventid_seq',
    GREATEST((SELECT MAX(c_eventid) FROM t_event), 1),
    (SELECT MAX(c_eventid) IS NOT NULL FROM t_event)
);

-- 4. REGISTRATION TABLE
CREATE TABLE IF NOT EXISTS t_registration (
    c_registrationid SERIAL PRIMARY KEY,
    c_userid INT NOT NULL REFERENCES t_user(c_userid) ON DELETE CASCADE,
    c_eventid INT NOT NULL REFERENCES t_event(c_eventid) ON DELETE CASCADE,
    c_registrationdate DATE NOT NULL,
    CONSTRAINT uq_user_event UNIQUE (c_userid, c_eventid)
);

INSERT INTO t_registration (
    c_registrationid, c_userid, c_eventid, c_registrationdate
) VALUES
    (301, 102, 201, '2026-09-20'),
    (302, 103, 201, '2026-09-21'),
    (303, 104, 202, '2026-09-22'),
    (304, 105, 202, '2026-09-23'),
    (305, 102, 203, '2026-09-24'),
    (306, 103, 203, '2026-09-25'),
    (307, 104, 203, '2026-09-26'),
    (308, 105, 204, '2026-09-27')
ON CONFLICT (c_registrationid) DO NOTHING;

SELECT setval(
    't_registration_c_registrationid_seq',
    GREATEST((SELECT MAX(c_registrationid) FROM t_registration), 1),
    (SELECT MAX(c_registrationid) IS NOT NULL FROM t_registration)
);