﻿using System.ComponentModel.DataAnnotations;

namespace EventMVC.Models;

public class t_Event
{
    public int c_eventid { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "City is required.")]
    public int c_cityid { get; set; }

    public string c_cityname { get; set; } = "";

    [Required(ErrorMessage = "Event name is required.")]
    public string c_eventname { get; set; } = "";

    [Required(ErrorMessage = "Event date is required.")]
    public DateOnly c_eventdate { get; set; }

    [Required(ErrorMessage = "Event time is required.")]
    public TimeOnly c_eventtime { get; set; }

    [Required(ErrorMessage = "Venue is required.")]
    public string c_venue { get; set; } = "";

    public string? c_eventimage { get; set; }

    public string c_eventtype { get; set; } = "Solo";

    public string c_foodpreference { get; set; } = "Veg";

    [Range(0, 50000, ErrorMessage = "Total seats must not be negative.")]
    public int c_totalseats { get; set; }

    public int c_availableseats { get; set; }

    public IFormFile? EventImageFile { get; set; }
}