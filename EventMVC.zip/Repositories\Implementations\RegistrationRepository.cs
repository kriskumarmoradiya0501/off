﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Npgsql;

namespace EventMVC.Repositories.Implementations;

public class RegistrationRepository : IRegistrationInterface
{
    private readonly NpgsqlConnection _connection;

    public RegistrationRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<List<t_Registration>> GetMyRegistrations(int userId)
    {
        List<t_Registration> registrations = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT r.c_registrationid, r.c_userid, r.c_eventid, r.c_registrationdate,
                       e.c_eventname, e.c_eventdate, e.c_eventtime, e.c_venue, e.c_eventimage,
                       e.c_eventtype, e.c_foodpreference, e.c_totalseats, c.c_cityname,
                       e.c_totalseats - (
                           SELECT COUNT(*)::INT
                           FROM t_registration x
                           WHERE x.c_eventid = e.c_eventid
                       ) AS available
                FROM t_registration r
                INNER JOIN t_event e ON r.c_eventid = e.c_eventid
                LEFT JOIN t_city c ON e.c_cityid = c.c_cityid
                WHERE r.c_userid = @userId
                ORDER BY r.c_registrationdate DESC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@userId", userId);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                registrations.Add(new t_Registration
                {
                    c_registrationid = Convert.ToInt32(reader["c_registrationid"]),
                    c_userid = Convert.ToInt32(reader["c_userid"]),
                    c_eventid = Convert.ToInt32(reader["c_eventid"]),
                    c_registrationdate = DateOnly.FromDateTime(Convert.ToDateTime(reader["c_registrationdate"])),
                    c_eventname = reader["c_eventname"].ToString()!,
                    c_eventdate = DateOnly.FromDateTime(Convert.ToDateTime(reader["c_eventdate"])),
                    c_eventtime = TimeOnly.FromTimeSpan((TimeSpan)reader["c_eventtime"]),
                    c_venue = reader["c_venue"].ToString()!,
                    c_cityname = reader["c_cityname"] == DBNull.Value ? "" : reader["c_cityname"].ToString()!,
                    c_eventimage = reader["c_eventimage"] == DBNull.Value ? "" : reader["c_eventimage"].ToString(),
                    c_eventtype = reader["c_eventtype"].ToString()!,
                    c_foodpreference = reader["c_foodpreference"].ToString()!,
                    c_totalseats = Convert.ToInt32(reader["c_totalseats"]),
                    c_availableseats = Convert.ToInt32(reader["available"])
                });
            }

            return registrations;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<bool> IsAlreadyRegistered(int userId, int eventId)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT COUNT(*)::INT
                FROM t_registration
                WHERE c_userid = @userId
                  AND c_eventid = @eventId;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@userId", userId);
            command.Parameters.AddWithValue("@eventId", eventId);

            int count = Convert.ToInt32(await command.ExecuteScalarAsync());

            return count > 0;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Register(int userId, int eventId, DateOnly registrationDate)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                INSERT INTO t_registration (c_userid, c_eventid, c_registrationdate)
                SELECT @userId, e.c_eventid, @registrationDate
                FROM t_event e
                WHERE e.c_eventid = @eventId
                  AND @registrationDate <= e.c_eventdate
                  AND e.c_totalseats > (
                      SELECT COUNT(*)::INT
                      FROM t_registration r
                      WHERE r.c_eventid = e.c_eventid
                  )
                ON CONFLICT (c_userid, c_eventid) DO NOTHING;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@userId", userId);
            command.Parameters.AddWithValue("@eventId", eventId);
            command.Parameters.AddWithValue("@registrationDate", registrationDate);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Cancel(int registrationId, int userId)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                DELETE FROM t_registration
                WHERE c_registrationid = @id
                  AND c_userid = @userId;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", registrationId);
            command.Parameters.AddWithValue("@userId", userId);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}