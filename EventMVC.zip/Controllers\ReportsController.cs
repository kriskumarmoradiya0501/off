﻿using EventMVC.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class ReportsController : Controller
{
    private readonly IReportInterface _reportRepository;

    public ReportsController(IReportInterface reportRepository)
    {
        _reportRepository = reportRepository;
    }

    private bool IsAdmin()
    {
        return HttpContext.Session.GetString("UserRole") == "Admin";
    }

    [HttpGet]
    public IActionResult Index()
    {
        if (!IsAdmin())
        {
            return RedirectToAction("Login", "Account");
        }

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> GetSeatAvailabilityReport()
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        return Json(await _reportRepository.GetSeatAvailabilityReport());
    }

    [HttpGet]
    public async Task<IActionResult> GetUserSummaryReport()
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        return Json(await _reportRepository.GetUserRegistrationSummary());
    }

    [HttpGet]
    public async Task<IActionResult> GetLowAvailabilityReport()
    {
        if (!IsAdmin())
        {
            return Unauthorized();
        }

        return Json(await _reportRepository.GetLowAvailabilityReport());
    }
}