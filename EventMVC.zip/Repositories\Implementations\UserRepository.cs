﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Npgsql;

namespace EventMVC.Repositories.Implementations;

public class UserRepository : IUserInterface
{
    private readonly NpgsqlConnection _connection;

    public UserRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<t_User?> Login(string email, string password)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT u.c_userid, u.c_name, u.c_email, u.c_password, u.c_mobile,
                       u.c_gender, u.c_hobbies, u.c_cityid, c.c_cityname,
                       u.c_profileimage, u.c_role
                FROM t_user u
                LEFT JOIN t_city c ON u.c_cityid = c.c_cityid
                WHERE LOWER(u.c_email) = LOWER(@email)
                  AND u.c_password = @password;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new t_User
                {
                    c_userid = Convert.ToInt32(reader["c_userid"]),
                    c_name = reader["c_name"].ToString()!,
                    c_email = reader["c_email"].ToString()!,
                    c_password = reader["c_password"].ToString()!,
                    c_mobile = reader["c_mobile"].ToString()!,
                    c_gender = reader["c_gender"].ToString()!,
                    c_hobbies = reader["c_hobbies"] == DBNull.Value ? "" : reader["c_hobbies"].ToString(),
                    c_cityid = reader["c_cityid"] == DBNull.Value ? 0 : Convert.ToInt32(reader["c_cityid"]),
                    c_cityname = reader["c_cityname"] == DBNull.Value ? "" : reader["c_cityname"].ToString()!,
                    c_profileimage = reader["c_profileimage"] == DBNull.Value ? "" : reader["c_profileimage"].ToString(),
                    c_role = reader["c_role"].ToString()!
                };
            }

            return null;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<bool> EmailExists(string email)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT COUNT(*)::INT
                FROM t_user
                WHERE LOWER(c_email) = LOWER(@email);
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@email", email);

            int count = Convert.ToInt32(await command.ExecuteScalarAsync());

            return count > 0;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> RegisterUser(t_User user)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                INSERT INTO t_user (
                    c_name, c_email, c_password, c_mobile,
                    c_gender, c_hobbies, c_cityid, c_profileimage, c_role
                ) VALUES (
                    @name, @email, @password, @mobile,
                    @gender, @hobbies, @cityid, @profileimage, 'User'
                );
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@name", user.c_name);
            command.Parameters.AddWithValue("@email", user.c_email);
            command.Parameters.AddWithValue("@password", user.c_password);
            command.Parameters.AddWithValue("@mobile", user.c_mobile);
            command.Parameters.AddWithValue("@gender", user.c_gender);
            command.Parameters.AddWithValue("@hobbies", (object?)user.c_hobbies ?? DBNull.Value);
            command.Parameters.AddWithValue("@cityid", user.c_cityid);
            command.Parameters.AddWithValue("@profileimage", (object?)user.c_profileimage ?? DBNull.Value);

            return await command.ExecuteNonQueryAsync();
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<t_User?> GetById(int id)
    {
        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT c_userid, c_name, c_email, c_mobile, c_gender, c_cityid, c_role
                FROM t_user
                WHERE c_userid = @id;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            command.Parameters.AddWithValue("@id", id);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return new t_User
                {
                    c_userid = Convert.ToInt32(reader["c_userid"]),
                    c_name = reader["c_name"].ToString()!,
                    c_email = reader["c_email"].ToString()!,
                    c_mobile = reader["c_mobile"].ToString()!,
                    c_gender = reader["c_gender"].ToString()!,
                    c_cityid = Convert.ToInt32(reader["c_cityid"]),
                    c_role = reader["c_role"].ToString()!
                };
            }

            return null;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}