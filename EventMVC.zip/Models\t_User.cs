﻿using System.ComponentModel.DataAnnotations;

namespace EventMVC.Models;

public class t_User
{
    public int c_userid { get; set; }

    [Required(ErrorMessage = "Name is required.")]
    public string c_name { get; set; } = "";

    [Required(ErrorMessage = "Email is required.")]
    [EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string c_email { get; set; } = "";

    [Required(ErrorMessage = "Password is required.")]
    public string c_password { get; set; } = "";

    [Required(ErrorMessage = "Mobile is required.")]
    public string c_mobile { get; set; } = "";

    [Required(ErrorMessage = "Gender is required.")]
    public string c_gender { get; set; } = "";

    public string? c_hobbies { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "City is required.")]
    public int c_cityid { get; set; }

    public string c_cityname { get; set; } = "";

    public string? c_profileimage { get; set; }

    public string c_role { get; set; } = "User";

    public IFormFile? ProfileImageFile { get; set; }
}