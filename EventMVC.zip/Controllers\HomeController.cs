﻿using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        string? role = HttpContext.Session.GetString("UserRole");

        if (role == "Admin")
        {
            return RedirectToAction("Index", "Event");
        }

        if (role == "User")
        {
            return RedirectToAction("Index", "Registration");
        }

        return RedirectToAction("Login", "Account");
    }
}