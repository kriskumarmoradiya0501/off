﻿using EventMVC.Models;
using EventMVC.Repositories.Interfaces;
using Npgsql;

namespace EventMVC.Repositories.Implementations;

public class ReportRepository : IReportInterface
{
    private readonly NpgsqlConnection _connection;

    public ReportRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    // Report 1: Event Seat Availability
    public async Task<List<EventSeatReportModel>> GetSeatAvailabilityReport()
    {
        List<EventSeatReportModel> report = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.c_eventname,
                       e.c_totalseats,
                       COUNT(r.c_registrationid)::INT AS registered,
                       e.c_totalseats - COUNT(r.c_registrationid)::INT AS remaining,
                       CASE
                           WHEN e.c_totalseats > 0
                           THEN ROUND((COUNT(r.c_registrationid)::NUMERIC * 100.0) / e.c_totalseats, 2)
                           ELSE 0
                       END AS occupancy
                FROM t_event e
                LEFT JOIN t_registration r ON e.c_eventid = r.c_eventid
                GROUP BY e.c_eventid, e.c_eventname, e.c_totalseats
                ORDER BY e.c_eventid ASC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                report.Add(new EventSeatReportModel
                {
                    EventName = reader["c_eventname"].ToString()!,
                    TotalSeats = Convert.ToInt32(reader["c_totalseats"]),
                    RegisteredSeats = Convert.ToInt32(reader["registered"]),
                    RemainingSeats = Convert.ToInt32(reader["remaining"]),
                    OccupancyPercentage = reader["occupancy"].ToString() + "%"
                });
            }

            return report;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Report 2: User Registration Summary
    public async Task<List<UserSummaryReportModel>> GetUserRegistrationSummary()
    {
        List<UserSummaryReportModel> summary = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT u.c_name,
                       COUNT(r.c_registrationid)::INT AS total_events,
                       COALESCE(TO_CHAR(MAX(r.c_registrationdate), 'YYYY-MM-DD'), '-') AS latest_date
                FROM t_user u
                INNER JOIN t_registration r ON u.c_userid = r.c_userid
                WHERE u.c_role = 'User'
                GROUP BY u.c_userid, u.c_name
                ORDER BY u.c_name ASC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                summary.Add(new UserSummaryReportModel
                {
                    UserName = reader["c_name"].ToString()!,
                    TotalEventsRegistered = Convert.ToInt32(reader["total_events"]),
                    LatestRegistration = reader["latest_date"].ToString()!
                });
            }

            return summary;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    // Report 3: Fully Booked / Low Availability Events
    public async Task<List<EventAvailabilityStatusModel>> GetLowAvailabilityReport()
    {
        List<EventAvailabilityStatusModel> statusReport = new();

        await _connection.OpenAsync();

        try
        {
            string query = @"
                SELECT e.c_eventname,
                       e.c_totalseats,
                       COUNT(r.c_registrationid)::INT AS registered,
                       e.c_totalseats - COUNT(r.c_registrationid)::INT AS remaining,
                       CASE
                           WHEN (e.c_totalseats - COUNT(r.c_registrationid)::INT) = 0 THEN 'Fully Booked'
                           WHEN (e.c_totalseats - COUNT(r.c_registrationid)::INT) <= 10 THEN 'Almost Full'
                           ELSE 'Available'
                       END AS status
                FROM t_event e
                LEFT JOIN t_registration r ON e.c_eventid = r.c_eventid
                GROUP BY e.c_eventid, e.c_eventname, e.c_totalseats
                ORDER BY remaining ASC;
            ";

            using NpgsqlCommand command = new NpgsqlCommand(query, _connection);

            using NpgsqlDataReader reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                statusReport.Add(new EventAvailabilityStatusModel
                {
                    EventName = reader["c_eventname"].ToString()!,
                    TotalSeats = Convert.ToInt32(reader["c_totalseats"]),
                    RegisteredSeats = Convert.ToInt32(reader["registered"]),
                    RemainingSeats = Convert.ToInt32(reader["remaining"]),
                    Status = reader["status"].ToString()!
                });
            }

            return statusReport;
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}