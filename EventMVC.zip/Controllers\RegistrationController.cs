﻿using EventMVC.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EventMVC.Controllers;

public class RegistrationController : Controller
{
    private readonly IRegistrationInterface _registrationRepository;
    private readonly IEventInterface _eventRepository;

    public RegistrationController(
        IRegistrationInterface registrationRepository,
        IEventInterface eventRepository)
    {
        _registrationRepository = registrationRepository;
        _eventRepository = eventRepository;
    }

    private bool IsUser()
    {
        return HttpContext.Session.GetString("UserRole") == "User";
    }

    [HttpGet]
    public IActionResult Index()
    {
        if (!IsUser())
        {
            return RedirectToAction("Login", "Account");
        }

        return View();
    }

    [HttpGet]
    public async Task<IActionResult> ReadUpcomingEvents()
    {
        if (!IsUser())
        {
            return Unauthorized();
        }

        var events = await _eventRepository.GetAll();

        return Json(events);
    }

    [HttpGet]
    public async Task<IActionResult> ReadMyRegistrations()
    {
        if (!IsUser())
        {
            return Unauthorized();
        }

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        var myRegistrations = await _registrationRepository.GetMyRegistrations(userId);

        return Json(myRegistrations);
    }

    [HttpPost]
    public async Task<IActionResult> RegisterEvent(int eventId)
    {
        if (!IsUser())
        {
            return Unauthorized();
        }

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        var selectedEvent = await _eventRepository.GetById(eventId);

        if (selectedEvent == null)
        {
            return Json(new { success = false, message = "Event was not found." });
        }

        DateOnly today = DateOnly.FromDateTime(DateTime.Now);

        if (today > selectedEvent.c_eventdate)
        {
            return Json(new { success = false, message = "Cannot register for an event that has already passed." });
        }

        if (await _registrationRepository.IsAlreadyRegistered(userId, eventId))
        {
            return Json(new { success = false, message = "You have already registered for this event." });
        }

        if (selectedEvent.c_availableseats <= 0)
        {
            return Json(new { success = false, message = "Registration failed. This event is fully booked." });
        }

        int result = await _registrationRepository.Register(userId, eventId, today);

        if (result > 0)
        {
            return Json(new { success = true, message = "Event registered successfully!" });
        }

        return Json(new { success = false, message = "Registration could not be completed." });
    }

    [HttpPost]
    public async Task<IActionResult> CancelRegistration(int registrationId)
    {
        if (!IsUser())
        {
            return Unauthorized();
        }

        int userId = HttpContext.Session.GetInt32("UserId")!.Value;

        int result = await _registrationRepository.Cancel(registrationId, userId);

        if (result > 0)
        {
            return Json(new { success = true, message = "Registration cancelled successfully." });
        }

        return Json(new { success = false, message = "Cancellation failed." });
    }
}